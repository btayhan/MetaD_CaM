# Load your files
set inputpsf "../holo_p_1.pdb"
set inputdcd "../holo_p_1.dcd"
set outputfile "./holo_p_1_glu_asp_cla.dat"

# Load the trajectory
mol load pdb $inputpsf dcd $inputdcd

# Atom selection
# Selection 1: Sidechain atoms of GLU and ASP residues from the protein
set sel1 [atomselect top "protein and sidechain and resname GLU or resname ASP"]

# Selection 2: All potassium (POT) ions
set sel2 [atomselect top "resname CLA"]

# Print info to terminal
puts "Selection 1: protein and sidechain and resname GLU or resname ASP"
puts "Number of atoms in sel1: [$sel1 num]"
puts "Selection 2: resname CLA"
puts "Number of atoms in sel2: [$sel2 num]"

# Compute RDF (Radial Distribution Function)
# Note: selupdate 1 updates selections at each frame (important for dynamics!)
set outfile [open $outputfile w]
set gr0 [measure gofr $sel1 $sel2 delta 0.1 rmax 20.0 usepbc 1 selupdate 1 first 0 last -1 step 1]

# Extract results
set r [lindex $gr0 0]     ;# Distance bins
set gr [lindex $gr0 1]    ;# g(r)
set igr [lindex $gr0 2]   ;# Integrated g(r)
set isto [lindex $gr0 3]  ;# Histogram counts

# Write to output file
foreach j $r k $gr l $igr m $isto {
    puts $outfile [format "%.4f\t%.4f\t%.4f\t%.4f" $j $k $l $m]
}
close $outfile

# Clean up and exit
exit

